try:
    from PIL import Image
except ImportError:
    import Image
import pytesseract
import pyautogui
import pyscreenshot as ImageGrab
import os
import time
import cv2
import numpy as np
import platform
import subprocess
import random
import sys
import keyboard
import asyncio
import os
try:
    from PIL import Image
except ImportError:
    import Image
import pyautogui
is_retina = False
if platform.system() == "Darwin":
    is_retina = subprocess.call("system_profiler SPDisplaysDataType | grep 'retina'", shell=True)
def imagesearch(image, precision=0.8):
    im = pyautogui.screenshot()
    if is_retina:
        im.thumbnail((round(im.size[0] * 0.5), round(im.size[1] * 0.5)))
    # im.save('testarea.png') useful for debugging purposes, this will save the captured region as "testarea.png"
    img_rgb = np.array(im)
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
    template = cv2.imread(image, 0)
    template.shape[::-1]

    res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
    if max_val < precision:
        return [-1, -1]
    return max_loc
def region_grabber(region):
    if is_retina: region = [n * 2 for n in region]
    x1 = region[0]
    y1 = region[1]
    width = region[2] - x1
    height = region[3] - y1

    return pyautogui.screenshot(region=(x1, y1, width, height))
def imagesearcharea(image, x1, y1, x2, y2, precision=0.8, im=None):
    if im is None:
        im = region_grabber(region=(x1, y1, x2, y2))
        if is_retina:
            im.thumbnail((round(im.size[0] * 0.5), round(im.size[1] * 0.5)))
        # im.save('testarea.png') usefull for debugging purposes, this will save the captured region as "testarea.png"

    img_rgb = np.array(im)
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
    template = cv2.imread(image, 0)

    res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
    if max_val < precision:
        return [-1, -1]
    return max_loc
import pyscreenshot as ImageGrab
import pytesseract
def pos():
    print(pyautogui.position())

print(pyautogui.position())
def bckenderror():
   onko= imagesearcharea("bckenderror.png", 724, 473, 1191, 607, precision=0.8, im=None)
   print (onko)
#bckenderror()
if imagesearch('etusivu.png', precision=0.8) != [-1, -1]:
    # klikkaa trading
    pyautogui.moveTo(950, 798, 1)
    pyautogui.click(None, None)
    # klikkaa flea market
    pyautogui.moveTo(953, 37, 1)
    pyautogui.click(None, None)
    # klikkaa searchbox
    pyautogui.moveTo(132, 121, 1)
    pyautogui.click(None, None)
    # kirjoittaa ja klikkaa
    pyautogui.typewrite("Factory exit key", interval= 0.2)
  #  pyautogui.typewrite()
    time.sleep(0.5)
    pyautogui.click(x=158, y=167)
#def hintakuva():
   # im = ImageGrab.grab(bbox=(1251, 150, 1423, 189))
#    # im = ImageGrab.grab(bbox=(1251, 155, 1423, 189))
#     #im = ImageGrab.grab(bbox=(934, 226, 964, 273))
#     im.save('im.png')
# #    x = pytesseract.image_to_string(Image.open('im.png'))
#     x=pytesseract.image_to_string(Image.open('im.png') ,config="-c tessedit_char_whitelist=123456789₽")
#   #  x = pytesseract.image_to_string(Image.open('im.png'), lang='rus')
#     print(x)
#     x = x.replace(" ", "")
#     print(x)
# #pytesseract.image
# pos()
# hintakuva()
